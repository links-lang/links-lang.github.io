(* Reject types called 'f' to avoid confusion with the overloaded type parameter *)
type f = F deriving (Functor)
